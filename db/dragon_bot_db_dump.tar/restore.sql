--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dragon_bot_development;
--
-- Name: dragon_bot_development; Type: DATABASE; Schema: -; Owner: will
--

CREATE DATABASE dragon_bot_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_CA.UTF-8' LC_CTYPE = 'en_CA.UTF-8';


ALTER DATABASE dragon_bot_development OWNER TO will;

\connect dragon_bot_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accessories; Type: TABLE; Schema: public; Owner: will
--

CREATE TABLE public.accessories (
    id bigint NOT NULL,
    name character varying NOT NULL,
    bandit boolean DEFAULT false,
    empress boolean DEFAULT false,
    oracle boolean DEFAULT false,
    shinobi boolean DEFAULT false,
    warrior boolean DEFAULT false,
    witch boolean DEFAULT false,
    level integer,
    str integer,
    agi integer,
    "int" integer,
    vit integer,
    luc integer,
    pie integer,
    atk integer,
    matk integer,
    def integer,
    mdef integer,
    acc integer,
    macc integer,
    crt integer,
    bonus text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.accessories OWNER TO will;

--
-- Name: accessories_id_seq; Type: SEQUENCE; Schema: public; Owner: will
--

CREATE SEQUENCE public.accessories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessories_id_seq OWNER TO will;

--
-- Name: accessories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: will
--

ALTER SEQUENCE public.accessories_id_seq OWNED BY public.accessories.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: will
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO will;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: will
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO will;

--
-- Name: weapons; Type: TABLE; Schema: public; Owner: will
--

CREATE TABLE public.weapons (
    id bigint NOT NULL,
    name character varying NOT NULL,
    type character varying,
    bandit boolean DEFAULT false,
    empress boolean DEFAULT false,
    oracle boolean DEFAULT false,
    shinobi boolean DEFAULT false,
    warrior boolean DEFAULT false,
    witch boolean DEFAULT false,
    level integer,
    str integer,
    agi integer,
    "int" integer,
    vit integer,
    luc integer,
    pie integer,
    atk integer,
    matk integer,
    def integer,
    mdef integer,
    acc integer,
    macc integer,
    crt integer,
    element character varying,
    bonus text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.weapons OWNER TO will;

--
-- Name: weapons_id_seq; Type: SEQUENCE; Schema: public; Owner: will
--

CREATE SEQUENCE public.weapons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.weapons_id_seq OWNER TO will;

--
-- Name: weapons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: will
--

ALTER SEQUENCE public.weapons_id_seq OWNED BY public.weapons.id;


--
-- Name: accessories id; Type: DEFAULT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.accessories ALTER COLUMN id SET DEFAULT nextval('public.accessories_id_seq'::regclass);


--
-- Name: weapons id; Type: DEFAULT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.weapons ALTER COLUMN id SET DEFAULT nextval('public.weapons_id_seq'::regclass);


--
-- Data for Name: accessories; Type: TABLE DATA; Schema: public; Owner: will
--

COPY public.accessories (id, name, bandit, empress, oracle, shinobi, warrior, witch, level, str, agi, "int", vit, luc, pie, atk, matk, def, mdef, acc, macc, crt, bonus) FROM stdin;
\.
COPY public.accessories (id, name, bandit, empress, oracle, shinobi, warrior, witch, level, str, agi, "int", vit, luc, pie, atk, matk, def, mdef, acc, macc, crt, bonus) FROM '$$PATH$$/2970.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: will
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2966.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: will
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: weapons; Type: TABLE DATA; Schema: public; Owner: will
--

COPY public.weapons (id, name, type, bandit, empress, oracle, shinobi, warrior, witch, level, str, agi, "int", vit, luc, pie, atk, matk, def, mdef, acc, macc, crt, element, bonus) FROM stdin;
\.
COPY public.weapons (id, name, type, bandit, empress, oracle, shinobi, warrior, witch, level, str, agi, "int", vit, luc, pie, atk, matk, def, mdef, acc, macc, crt, element, bonus) FROM '$$PATH$$/2968.dat';

--
-- Name: accessories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: will
--

SELECT pg_catalog.setval('public.accessories_id_seq', 1426, true);


--
-- Name: weapons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: will
--

SELECT pg_catalog.setval('public.weapons_id_seq', 1658, true);


--
-- Name: accessories accessories_pkey; Type: CONSTRAINT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.accessories
    ADD CONSTRAINT accessories_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: weapons weapons_pkey; Type: CONSTRAINT; Schema: public; Owner: will
--

ALTER TABLE ONLY public.weapons
    ADD CONSTRAINT weapons_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

